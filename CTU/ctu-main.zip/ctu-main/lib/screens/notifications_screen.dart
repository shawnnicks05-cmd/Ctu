import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/event_model.dart';
import '../utils/app_theme.dart';

enum _NotifFilter { all, unread, reminders }

class _InboxItem {
  const _InboxItem({
    required this.title,
    required this.timeLabel,
    this.location,
    required this.type,
    required this.unread,
    required this.section,
  });

  final String title;
  final String timeLabel;
  final String? location;
  final EventType type;
  final bool unread;
  final String section;
}

final List<_InboxItem> _kNotifications = [
  const _InboxItem(
    title: 'Prelim Examination',
    timeLabel: 'Today at 9:00 AM',
    location: 'Engineering Building',
    type: EventType.examination,
    unread: true,
    section: 'Today',
  ),
  const _InboxItem(
    title: 'Department Meeting',
    timeLabel: 'Today at 1:00 PM',
    location: 'Conference Room A',
    type: EventType.meeting,
    unread: true,
    section: 'Today',
  ),
  const _InboxItem(
    title: 'University Holiday',
    timeLabel: 'Today • All Day',
    location: null,
    type: EventType.holiday,
    unread: false,
    section: 'Today',
  ),
  const _InboxItem(
    title: 'Student Organization Fair',
    timeLabel: 'May 20, 2026 at 9:00 AM',
    location: 'CTU Gymnasium',
    type: EventType.extracurricular,
    unread: true,
    section: 'Earlier',
  ),
  const _InboxItem(
    title: 'Enrollment Period',
    timeLabel: 'May 13, 2026',
    location: 'Registrar Office',
    type: EventType.academic,
    unread: false,
    section: 'Earlier',
  ),
];

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  _NotifFilter _filter = _NotifFilter.all;

  List<_InboxItem> get _visible {
    return _kNotifications.where((n) {
      switch (_filter) {
        case _NotifFilter.all:
          return true;
        case _NotifFilter.unread:
          return n.unread;
        case _NotifFilter.reminders:
          return n.type == EventType.examination ||
              n.type == EventType.meeting ||
              n.type == EventType.academic;
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<_InboxItem>>{};
    for (final n in _visible) {
      grouped.putIfAbsent(n.section, () => []).add(n);
    }
    final order = ['Today', 'Earlier'];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            decoration: const BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Notifications',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 14),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _FilterChip(
                            label: 'All',
                            selected: _filter == _NotifFilter.all,
                            onTap: () =>
                                setState(() => _filter = _NotifFilter.all),
                          ),
                          const SizedBox(width: 10),
                          _FilterChip(
                            label: 'Unread',
                            selected: _filter == _NotifFilter.unread,
                            onTap: () =>
                                setState(() => _filter = _NotifFilter.unread),
                          ),
                          const SizedBox(width: 10),
                          _FilterChip(
                            label: 'Reminders',
                            selected: _filter == _NotifFilter.reminders,
                            onTap: () => setState(
                                () => _filter = _NotifFilter.reminders),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: [
                for (final key in order)
                  if (grouped[key] != null && grouped[key]!.isNotEmpty) ...[
                    Text(
                      key,
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...grouped[key]!.map((n) => _NotificationTile(item: n)),
                    const SizedBox(height: 18),
                  ],
                if (_visible.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 48),
                    child: Center(
                      child: Text(
                        'No notifications in this view.',
                        style: GoogleFonts.poppins(
                          color: AppColors.textSecondary,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: selected ? Colors.white : Colors.white54,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: selected ? AppColors.primary : const Color(0xFFE8E8E8),
            ),
          ),
        ),
      ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  const _NotificationTile({required this.item});

  final _InboxItem item;

  IconData get _icon {
    switch (item.type) {
      case EventType.academic:
        return Icons.menu_book_rounded;
      case EventType.examination:
        return Icons.assignment_rounded;
      case EventType.holiday:
        return Icons.event_rounded;
      case EventType.extracurricular:
        return Icons.groups_rounded;
      case EventType.meeting:
        return Icons.groups_2_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.eventColor(item.type);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: c.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(_icon, color: c, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  item.timeLabel,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
                if (item.location != null) ...[
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Icon(Icons.location_on_rounded,
                          size: 14, color: AppColors.textSecondary),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(
                          item.location!,
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (item.unread)
            Padding(
              padding: const EdgeInsets.only(left: 6, top: 4),
              child: Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
